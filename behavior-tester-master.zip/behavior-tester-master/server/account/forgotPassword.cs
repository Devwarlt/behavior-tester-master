﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;
using common;
using System.Collections.Specialized;
using System.IO;
using System.Web;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Security.Cryptography;

namespace server.account
{
    class forgotPassword : RequestHandler
    {
        private static string CreatePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            var res = "";
            var rnd = new Random();
            while (0 < length--)
                res += valid[rnd.Next(valid.Length)];
            return res;
        }

        public bool IsValidEmail(string strIn)
        {
            var invalid = false;
            if (String.IsNullOrEmpty(strIn))
                return false;

            MatchEvaluator domainMapper = match =>
            {
                // IdnMapping class with default property values.
                var idn = new IdnMapping();

                var domainName = match.Groups[2].Value;
                try
                {
                    domainName = idn.GetAscii(domainName);
                }
                catch (ArgumentException)
                {
                    invalid = true;
                }
                return match.Groups[1].Value + domainName;
            };

            // Use IdnMapping class to convert Unicode domain names. 
            strIn = Regex.Replace(strIn, @"(@)(.+)$", domainMapper);
            if (invalid)
                return false;

            // Return true if strIn is in valid e-mail format. 
            return Regex.IsMatch(strIn,
                      @"^(?("")(""[^""]+?""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                      @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9]{2,17}))$",
                      RegexOptions.IgnoreCase);
        }

        public override void HandleRequest(HttpListenerContext context)
        {
            NameValueCollection query;
            using (StreamReader rdr = new StreamReader(context.Request.InputStream))
                query = HttpUtility.ParseQueryString(rdr.ReadToEnd());

            DbAccount acc;
            var status = Database.Verify(query["email"], "", out acc);
            if (!IsValidEmail(query["email"]))
                Write(context, "<Error>Invalid email</Error>");
            else if (status == LoginStatus.AccountNotExists)
                Write(context, "<Error>Account not found</Error>");
            else
            {
                var Account = Database.GetAccount(query["email"]);
                Account.PassResetToken = Convert.ToBase64String(Utils.SHA1(CreatePassword(5) + query["email"] + Account.AccountId + CreatePassword(5)));
                Account.Flush();

                var to = query["email"];
                const string @from = "noreply@nillysrealm.com";
                var message = new MailMessage(from, to)
                {
                    Subject = "Password Reset Request on Nilly's Realm"
                };
                var resetLink = "http://test.nillysrealm.com/account/rp?b=${b}&a=${a}".Replace("${b}", Account.PassResetToken).Replace("${a}", Database.GetAccount(query["email"]).AccountId.ToString());
                message.Body = @"Hello,

If you wish to reset your password on Nilly's Realm - Realm of the Mad God Private Server, Please use the link below:

" + resetLink + @"

If you do NOT wish to reset your password, do nothing.

Do not reply to this email, it will not be read. If you need support, go here:

http://nillysrealm.com/forum/viewforum.php?f=14

- Nilly's Realm Team
http://nillysrealm.com/";
                var client = new SmtpClient
                {
                    Port = 587,
                    Host = "smtp.mandrillapp.com",
                    Credentials = new NetworkCredential("LuciTheForgotten@gmail.com",
                        "oqoYeTQpJLnqzsqjMINz2Q")
                };
                try {
                    client.Send(message);
                    return;
                }
                catch { }
            }
        }
    }
}
