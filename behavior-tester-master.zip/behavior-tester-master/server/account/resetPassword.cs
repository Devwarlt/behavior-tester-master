﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;
using common;
using System.Collections.Specialized;
using System.IO;
using System.Web;
using System.Text.RegularExpressions;
using System.Globalization;

namespace server.account
{
    class resetPassword : RequestHandler
    {
        private static string CreatePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            var res = "";
            var rnd = new Random();
            while (0 < length--)
                res += valid[rnd.Next(valid.Length)];
            return res;
        }

        public override void HandleRequest(System.Net.HttpListenerContext context)
        {
            NameValueCollection query;
            using (StreamReader rdr = new StreamReader(context.Request.InputStream))
                query = HttpUtility.ParseQueryString(rdr.ReadToEnd());

            if (query.AllKeys.Length == 0)
            {
                string queryString = string.Empty;
                string currUrl = context.Request.RawUrl;
                int iqs = currUrl.IndexOf('?');
                if (iqs >= 0)
                {
                    query =
                        HttpUtility.ParseQueryString((iqs < currUrl.Length - 1)
                            ? currUrl.Substring(iqs + 1)
                            : String.Empty);
                }
            }

            Random rand = new Random();
            DbAccount acc = Database.GetAccount(Convert.ToInt32(query["a"]));
            if (acc.PassResetToken == query["b"])
            {
                var password = CreatePassword(rand.Next(8, 12));
                Database.ChangePassword(acc.UUID, password);

                acc.PassResetToken = "";
                acc.Flush();

                var to = acc.UUID;
                const string @from = "noreply@nillysrealm.com";
                var message = new MailMessage(from, to)
                {
                    Subject = "New Password on Nilly's Realm"
                };
                message.Body = @"Hello,

Your new password is: " + password + @"

Passwords are CaSe-SeNsItIvE!

You can change your password using the 'account' link on the title screen.

Now come play at: http://test.nillysrealm.com/

Do not reply to this email, it will not be read. If you need support, go here:

http://nillysrealm.com/forum/viewforum.php?f=14

- Nilly's Realm Team
http://nillysrealm.com/";
                var client = new SmtpClient
                {
                    Port = 587,
                    Host = "smtp.mandrillapp.com",
                    Credentials = new NetworkCredential("LuciTheForgotten@gmail.com",
                        "oqoYeTQpJLnqzsqjMINz2Q")
                };
                try
                {
                    client.Send(message);
                }
                catch { }

                var html = @"<html lang='en'>
    <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
        <title>Email Address Verified</title>
        <style>
            body { margin: 0; padding: 0; overflow: hidden;
            background-color: #000; color: #fff; font-family: verdana }
            :link { color: #ccf; }
            :visited { color: #fcf; }
        </style>
    </head>
    <body>
    <center>
        <br/>
        <p>Your new password is: " + password + @"</p>
        <p>It has also been emailed to you.</p>
        <p>Passwords are CaSe-SeNsItIvE!</p>
        <p>You can change your password using the <b>'account'</b> link on the title screen.</p>
    </center>
    </body>
</html>";
                var response = Encoding.UTF8.GetBytes(html);
                context.Response.OutputStream.Write(response, 0, response.Length);
            }
            else
            {
                var html = @"<html lang='en'>
    <head>
        <meta http-equiv='Content-Type' contet='text/html; charset=utf-8'>
        <title>Error Verifying Email Address</title>
        <style>
            body { margin: 0; padding: 0; overflow: hidden;
            background-color: #000; color: #fff; font-family: verdana }
            :link { color: #ccf; }
            :visited { color: #fcf; }
        </style>
    </head>
    <body>
    <center>
        <br/>
        <b><font color='red'>Unable to Reset Password</b>
    </center>
    </body>
</html>";
                var response = Encoding.UTF8.GetBytes(html);
                context.Response.OutputStream.Write(response, 0, response.Length);
            }
        }
    }
}
