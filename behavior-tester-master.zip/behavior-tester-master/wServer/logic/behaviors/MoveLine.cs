using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using wServer.realm;
using common;
using Mono.Game;
using wServer.realm.entities;

namespace wServer.logic.behaviors
{
    class MoveLine : CycleBehavior
    {
        //State storage: protect state
        enum MoveLineState
        {
            DontKnowWhere,
            Protecting,
            Protected,
        }

        float speed;
        float direction;
        public MoveLine(double speed, double direction = 0)
        {
            this.speed = (float)speed;
            this.direction = (float)direction * (float)Math.PI / 180;
        }

        protected override void TickCore(Entity host, RealmTime time, ref object state)
        {
           
            Status = CycleStatus.NotStarted;
            if (host.HasConditionEffect(ConditionEffects.Paralyzed)) return;
            Vector2 vect;
            vect = new Vector2((float)Math.Cos(direction), (float)Math.Sin(direction));
            Status = CycleStatus.InProgress;
            vect.Normalize();
            float dist = host.GetSpeed(speed) * (time.thisTickTimes / 1000f);
            host.ValidateAndMove(host.X + vect.X * dist, host.Y + vect.Y * dist);
            host.UpdateCount++;
                    
                   
            }

        }
    }

