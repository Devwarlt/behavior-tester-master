using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using wServer.realm;
using common;
using wServer.realm.entities;
using wServer.networking.svrPackets;

namespace wServer.logic.behaviors
{
    class Heal : Behavior
    {
        //State storage: cooldown timer

        double range;
        string group;
        string name;
        int healAmount;
        Cooldown coolDown;

        public Heal(double range, string group = null, string name = null, double healAmount = -1, Cooldown coolDown = new Cooldown())
        {
            this.range = (float)range;
            this.group = group;
            this.name = name;
            this.healAmount = (int)healAmount;
            this.coolDown = coolDown.Normalize();
        }

        protected override void OnStateEntry(Entity host, RealmTime time, ref object state)
        {
            state = 0;
        }

        protected override void TickCore(Entity host, RealmTime time, ref object state)
        {
            int cool = (int)state;

            if (cool <= 0)
            {
                if (host.HasConditionEffect(ConditionEffects.Stunned)) return;
                if (group != null)
                {
                    foreach (var entity in host.GetNearestEntitiesByGroup(range, group).OfType<Enemy>())
                    {
                        int MaxHP = entity.ObjectDesc.MaxHP;
                        int HealHP = entity.HP + healAmount;
                        if (HealHP > MaxHP) HealHP = MaxHP;
                        if (HealHP != entity.HP)
                        {
                            int n = HealHP - entity.HP;
                            entity.HP = HealHP;
                            entity.UpdateCount++;
                            entity.Owner.BroadcastPacket(new ShowEffectPacket()
                            {
                                EffectType = EffectType.Potion,
                                TargetId = entity.Id,
                                Color = new ARGB(0xffffffff)
                            }, null);
                            entity.Owner.BroadcastPacket(new ShowEffectPacket()
                            {
                                EffectType = EffectType.Trail,
                                TargetId = host.Id,
                                PosA = new Position() { X = entity.X, Y = entity.Y },
                                Color = new ARGB(0xffffffff)
                            }, null);
                            entity.Owner.BroadcastPacket(new NotificationPacket()
                            {
                                ObjectId = entity.Id,
                                Text = "+" + n,
                                Color = new ARGB(0xff00ff00)
                            }, null);
                        }
                    }
                }
                else if(name != null)
                {
                    foreach (var entity in host.GetNearestEntitiesByName(range, name).OfType<Enemy>())
                    {
                        int MaxHP = entity.ObjectDesc.MaxHP;
                        int HealHP = entity.HP + healAmount;
                        if (HealHP > MaxHP || healAmount == -1) HealHP = MaxHP;
                        if (HealHP != entity.HP)
                        {
                            int n = HealHP - entity.HP;
                            entity.HP = HealHP;
                            entity.UpdateCount++;
                            entity.Owner.BroadcastPacket(new ShowEffectPacket()
                            {
                                EffectType = EffectType.Potion,
                                TargetId = entity.Id,
                                Color = new ARGB(0xffffffff)
                            }, null);
                            entity.Owner.BroadcastPacket(new ShowEffectPacket()
                            {
                                EffectType = EffectType.Trail,
                                TargetId = host.Id,
                                PosA = new Position() { X = entity.X, Y = entity.Y },
                                Color = new ARGB(0xffffffff)
                            }, null);
                            entity.Owner.BroadcastPacket(new NotificationPacket()
                            {
                                ObjectId = entity.Id,
                                Text = "+" + n,
                                Color = new ARGB(0xff00ff00)
                            }, null);
                        }
                    }
                }
                else
                {
                  /*      int MaxHP = host.ObjectDesc.MaxHP;
                        int HealHP = host.HP + healAmount;
                        if (HealHP > MaxHP) HealHP = MaxHP;
                        if (HealHP != host.HP)
                        {
                            int n = HealHP - host.HP;
                            host.HP = HealHP;
                            host.UpdateCount++;
                            host.Owner.BroadcastPacket(new ShowEffectPacket()
                            {
                                EffectType = EffectType.Potion,
                                TargetId = host.Id,
                                Color = new ARGB(0xffffffff)
                            }, null);
                            host.Owner.BroadcastPacket(new NotificationPacket()
                            {
                                ObjectId = host.Id,
                                Text = "+" + n,
                                Color = new ARGB(0xff00ff00)
                            }, null);
                        }*/
                }
                cool = coolDown.Next(Random);
            }
            else
                cool -= time.thisTickTimes;

            state = cool;
        }
    }
}
