using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using wServer.realm;
using common;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
	partial class BehaviorDb
	{
		_ Sheep = () => Behav()
			.Init("Sheep",
				new State(
					new State("Life",
					new Prioritize(
						new Wander(0.05)
					),
					new PlayerWithinTransition(20,"Baa")
				),
					new State("Baa",
						new Prioritize(
							new Wander(0.05)
						),
						new Taunt(0.10,"Baa !"),
						new TimedTransition(10000,"Life")
						)
				)
			)
			;
	}
}
