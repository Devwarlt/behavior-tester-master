using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using wServer.realm;
using common;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        _ MaskedPartyGod = () => Behav()
                .Init("Masked Party God",
                        new State(
                                new State("Idle",
                                    new PlayerWithinTransition(10, "Start")
                                    ),
                                new State("Start",
                                        new Taunt(0.99, "Oh no, Mixcoatl is my brother, I prefer partying to fighting"),
                                                new HpLessTransition(0.9999, "Commenting")
                                ),
                                new State("Commenting",
                                      new State("PickComment",
                                          new TimedTransition(2500, "Comment1", randomized: true),
                                          new TimedTransition(2500, "Comment2", randomized: true),
                                          new TimedTransition(2500, "Comment3", randomized: true),
                                          new TimedTransition(2500, "Comment4", randomized: true),
                                          new TimedTransition(2500, "Comment5", randomized: true),
                                          new TimedTransition(2500, "Comment6", randomized: true),
                                          new HpLessTransition(.2, "Comment9"),
                                          new HpLessTransition(.4, "Comment8"),
                                          new HpLessTransition(.6, "Comment7")
                                      ),
                                      new State("Comment1",
                                              new Taunt(0.99, "Lets have a fun-time in the sun-shine!"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment2",
                                              new Taunt(0.99, "Nothing like relaxin' on the beach"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment3",
                                              new Taunt(0.99, "Chilin' is the name of the game!"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment4",
                                              new Taunt(0.99, "How do you like my shades?"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment5",
                                              new Taunt(0.99, "EVERYBODY BOOGEY!"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment6",
                                              new Taunt(0.99, "What a beautiful day!"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment7",
                                              new Taunt(0.99, "Whoa there!"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment8",
                                              new Taunt(0.99, "Oh Snap"),
                                              new TimedTransition(300, "Texture0")
                                      ),
                                      new State("Comment9",
                                              new Taunt(0.99, "Ho!"),
                                              new TimedTransition(300, "Texture0")
                                      ),
										new State("Texture0",
											new SetAltTexture(0), 
											new TimedTransition(200,"Texture1")
									),
										new State("Texture1",
												new SetAltTexture(1), 
												new TimedTransition(200,"Texture3")
									),
										new State("Texture3",
											new SetAltTexture(2), 
											new TimedTransition(1200, "PickComment")
									)
                                ),
                                new Heal(1, name: "Masked Party God", coolDown: 5000),
                                new TimedTransition(6000, "Comment1")
                        ),
                        new Threshold(0.01,
                        new ItemLoot("Blue Paradise", 0.25),
                        new ItemLoot("Pink Passion Breeze", 0.25),
                        new ItemLoot("Bahama Sunrise", 0.25),
                        new ItemLoot("Lime Jungle Bay", 0.25)
                        )
                        )
                ;
    }
}
