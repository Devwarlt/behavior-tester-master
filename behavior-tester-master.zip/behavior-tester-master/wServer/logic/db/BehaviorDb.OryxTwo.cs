using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using wServer.realm;
using common;
using wServer.logic.behaviors;
using wServer.logic.loot;
using wServer.logic.transitions;

namespace wServer.logic
{
    partial class BehaviorDb
    {
        _ Wine_Cellar = () => Behav()
            .Init("Oryx the Mad God 2",
            new State(
                new Taunt(cooldown: 6000, text: "Pathetic Mortals! I have {HP} hitpoints!", probability: .5),
                
                new State("Attack",
                    new Shoot(99, count: 7, shootAngle: 360/7, projectileIndex: 0),
                    new Shoot(20, count: 3, shootAngle: 10, projectileIndex: 2, coolDown: 900),
                    new State("Minions",
                         new Wander(.2),
                         new Spawn("Henchman of Oryx", maxChildren: 4, initialSpawn: .5, coolDown: 5000),
                         new State("Shooting",
                         new State("ConfuseBlast",
                             new Shoot(30, count: 3, shootAngle: 12, projectileIndex: 4, predictive: .5),
                             new TimedTransition(600, "SlowBlast", randomized: true),
                             new TimedTransition(600, "QuietBlast", randomized: true)
                             ),
                         new State("SlowBlast",
                             new Shoot(30, count: 3, shootAngle: 12, projectileIndex: 1, coolDown: 1200),
                             new TimedTransition(600, "PinkRedBlast", randomized: true),
                             new TimedTransition(600, "PinkBlast", randomized: true)
                             ),
                         new State("PinkRedBlast",
                             new Shoot(30, count: 2, shootAngle: 12, projectileIndex: 3, coolDown: 1200),
                             new Shoot(30, count: 3, shootAngle: 12, projectileIndex: 6, coolDown: 1200),
                             new TimedTransition(600, "QuietBlast", randomized: true),
                             new TimedTransition(600, "ConfuseBlast", randomized: true),
                             new TimedTransition(600, "Respite", randomized: true)
                             ),
                         new State("QuietBlast",
                             new Shoot(30, count: 2, shootAngle: 12, projectileIndex: 5, coolDown: 1200, coolDownOffset: 340),
                             new TimedTransition(600, "SlowBlast", randomized: true),
                             new TimedTransition(600, "Respite", randomized: true)
                             ),
                         new State("PinkBlast",
                             new Shoot(30, count: 2, shootAngle: 12, projectileIndex: 3, coolDown: 1200),
                             new TimedTransition(600, "ConfuseBlast", randomized: true),
                             new TimedTransition(600, "QuietBlast", randomized: true),
                             new TimedTransition(600, "PinkRedBlast", randomized: true)
                             ),
                         new State("Respite",
                             new TimedTransition(600, "ConfuseBlast", randomized: true),
                             new TimedTransition(600, "SlowBlast", randomized: true),
                             new TimedTransition(600, "PinkBlast", randomized: true)
                             ),
                        new TimedTransition(10000, "Spawning")
                        ),
                        new State("Spawning",
                            new Spawn("Henchman of Oryx", maxChildren: 4, initialSpawn: .25, coolDown: 1000),
                            new TimedTransition(100, "Shooting")),
                             new HpLessTransition(.33, "NoMinions")
                        ),
                    new State("NoMinions",
                            new State("Opening",
                                 new Shoot(99, projectileIndex: 7, count: 36, fixedAngle: 0, shootAngle: 10, coolDown: 10000),
                                 new Taunt(cooldown: 100, text: "Can't... keep... minions... alive... anymore! ARGHH!!!"),
                                 new TimedTransition(10, "Respite2")
                                 ),
                            new Shoot(1, count: 36, shootAngle: 10, projectileIndex: 8, fixedAngle: 5, coolDown: 10000),
                            new Order(10, "Henchman of Oryx", "Suicide"),
                            new TossObject("Monstrosity Scarab", angle: 0, coolDown: 5000, range: 5),
                            new TossObject("Monstrosity Scarab", angle: 100, coolDown: 5000, range: 3),
                            new TossObject("Monstrosity Scarab", angle: 30, coolDown: 5000, range: 7),
                            new TossObject("Monstrosity Scarab", angle: 290, coolDown: 5000, range: 4),
                            new TossObject("Monstrosity Scarab", angle: 340, coolDown: 5000, range: 10),
                            new TossObject("Monstrosity Scarab", angle: 270, coolDown: 5000, range: 6),
                            new TossObject("Monstrosity Scarab", angle: 250, coolDown: 5000, range: 3),
                            new Prioritize(
                                new Follow(.4, acquireRange: 13, range: 1),
                                new Wander(.6)
                            ),
                              new State("ConfuseBlast2",
                                  new Shoot(30, count: 3, shootAngle: 12, projectileIndex: 4, predictive: .5),
                                  new TimedTransition(600, "SlowBlast2", randomized: true),
                                  new TimedTransition(600, "QuietBlast2", randomized: true)
                                  ),
                              new State("SlowBlast2",
                                  new Shoot(30, count: 3, shootAngle: 12, projectileIndex: 1, coolDown: 1200),
                                  new TimedTransition(600, "PinkRedBlast2", randomized: true),
                                  new TimedTransition(600, "PinkBlast2", randomized: true)
                                  ),
                              new State("PinkRedBlast2",
                                  new Shoot(30, count: 2, shootAngle: 12, projectileIndex: 3, coolDown: 1200),
                                  new Shoot(30, count: 3, shootAngle: 12, projectileIndex: 6, coolDown: 1200),
                                  new TimedTransition(600, "QuietBlast2", randomized: true),
                                  new TimedTransition(600, "ConfuseBlast2", randomized: true),
                                  new TimedTransition(600, "Respite2", randomized: true)
                                  ),
                              new State("QuietBlast2",
                                  new Shoot(30, count: 2, shootAngle: 12, projectileIndex: 5, coolDown: 1200, coolDownOffset: 340),
                                  new TimedTransition(600, "SlowBlast2", randomized: true),
                                  new TimedTransition(600, "Respite2", randomized: true)
                                  ),
                              new State("PinkBlast2",
                                  new Shoot(30, count: 2, shootAngle: 12, projectileIndex: 3, coolDown: 1200),
                                  new TimedTransition(600, "ConfuseBlast2", randomized: true),
                                  new TimedTransition(600, "QuietBlast2", randomized: true),
                                  new TimedTransition(600, "PinkRedBlast2", randomized: true)
                                  ),
                              new State("Respite2",
                                  new TimedTransition(600, "ConfuseBlast2", randomized: true),
                                  new TimedTransition(600, "SlowBlast2", randomized: true),
                                  new TimedTransition(600, "PinkBlast2", randomized: true)
                             )
                                 
                            )
                        )
                ),
                new TierLoot(13, ItemType.Armor, .05),
                new TierLoot(12, ItemType.Weapon, .05),
                new TierLoot(6, ItemType.Ability, .05),
                new TierLoot(12, ItemType.Armor, .1),
                new TierLoot(11, ItemType.Weapon, .1),
                new TierLoot(5, ItemType.Ability, .15),
                new TierLoot(5, ItemType.Ring, .1),
                new TierLoot(11, ItemType.Armor, .2),
                new TierLoot(10, ItemType.Weapon, .2),
                new TierLoot(4, ItemType.Ring, .2),
                new ItemLoot("Potion of Defense", .1),
                new ItemLoot("Potion of Attack", .1),
                new ItemLoot("Potion of Vitality", .1),
                new ItemLoot("Potion of Wisdom", .1)
                )
            .Init("Henchman of Oryx",
                new State(
                    new State("Attack",
                        new Prioritize(
                            new Orbit(.2, 2, target: "Oryx the Mad God 2", radiusVariance: 1),
                            new Wander(.3)
                            ),
                    new Shoot(15, predictive: 1, coolDown: 2500),
                    new Shoot(10, count: 3, shootAngle: 10, projectileIndex: 1, coolDown: 2500),
                    new Spawn("Vintner of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                  //  new Spawn("Bile of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                    new Spawn("Aberrant of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                    new Spawn("Monstrosity of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000),
                    new Spawn("Abomination of Oryx", maxChildren: 1, initialSpawn: 1, coolDown: 5000)
                            ),
                    new State("Suicide",
                        new Decay(0)
                             )
                            )
                            )
            .Init("Monstrosity of Oryx",
                new State(
                    new State("Wait", new PlayerWithinTransition(15,"Attack")),
                    new State("Attack",
                        new TimedTransition(10000, "Wait"),
                    new Prioritize(
                        new Orbit(.1, 6, target: "Oryx the Mad God 2", radiusVariance: 3),
                        new Follow(.1, acquireRange: 15),
                        new Wander(.2)
                        ),
                     new TossObject("Monstrosity Scarab", coolDown: 2500, range: 1, angle: 0, coolDownOffset: 1000)
                     )
                     ))
            .Init("Monstrosity Scarab",
                new State(
                    new State("Attack",
                    new State("Charge",
                        new Prioritize(
                            new Charge(range: 25, coolDown: 1000),
                            new Wander(.3)
                            ),
                        new PlayerWithinTransition(1, "Boom")
                        ),
                    new State("Boom",
                        new Shoot(1, count: 16, shootAngle: 360/16, fixedAngle: 0),
                        new Decay(0)
                       )
                       )
                       )
                       )
            .Init("Vintner of Oryx",
                new State(
                    new State("Attack",
                        new Prioritize(
                            new Protect(1, "Oryx the Mad God 2", protectionRange: 4, reprotectRange: 3),
                            new Charge(speed: 1, range: 15, coolDown: 2000),
                            new Protect(1, "Henchman of Oryx"),
                            new StayBack(1, 15),
                            new Wander(1)
                        ),
                        new Shoot(10, coolDown: 250)
                        )
                        ))
         .Init("Aberrant of Oryx",
            new State(
                new Prioritize(
                    new Protect(.2, "Oryx the Mad God 2"),
                    new Wander(.7)
                    ),
                new State("Wait", new PlayerWithinTransition(15, "Attack")),
                new State("Attack",
                new TimedTransition(10000, "Wait"),
                new State("Randomize",
                    new TimedTransition(100, "Toss1", randomized: true),
                    new TimedTransition(100, "Toss2", randomized: true),
                    new TimedTransition(100, "Toss3", randomized: true),
                    new TimedTransition(100, "Toss4", randomized: true),
                    new TimedTransition(100, "Toss5", randomized: true),
                    new TimedTransition(100, "Toss6", randomized: true),
                    new TimedTransition(100, "Toss7", randomized: true),
                    new TimedTransition(100, "Toss8", randomized: true)
                   ),
                new State("Toss1",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 0),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss2",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 45),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss3",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 90),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss4",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 135),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss5",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 180),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss6",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 225),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss7",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 270),
                    new TimedTransition(4900, "Randomize")
                    ),
                new State("Toss8",
                    new TossObject("Aberrant Blaster", coolDown: 40000, range: 5, angle: 315),
                    new TimedTransition(4900, "Randomize")
                    ))
                    ))
        .Init("Aberrant Blaster",
            new State(
                new State("Wait",
                    new PlayerWithinTransition(3, "Boom")
                    ),
                new State("Boom",
                    new Shoot(10, count: 5, shootAngle: 7),
                    new Decay(0)
                    )
                    )
                    )
        .Init("Bile of Oryx",
            new State(
                new Prioritize(
                    new Protect(.4, "Oryx the Mad God 2", protectionRange: 5, reprotectRange:4),
                    new Wander(.5)
                    )//,
                //new Spawn("Purple Goo", maxChildren: 20, initialSpawn: 0, coolDown: 1000)
                )
                )
        .Init("Abomination of Oryx",
            new State(
                new State("Shoot",
                    new Shoot(1, 3, shootAngle: 5, projectileIndex: 0),
                    new Shoot(1, 5, shootAngle: 5, projectileIndex: 1),
                    new Shoot(1, 7, shootAngle: 5, projectileIndex: 2),
                    new Shoot(1, 5, shootAngle: 5, projectileIndex: 3),
                    new Shoot(1, 3, shootAngle: 5, projectileIndex: 4),
                    new TimedTransition(1000, "Wait")
                    ),
                new State("Wait",
                    new PlayerWithinTransition(2, "Shoot")),
                new Prioritize(
                    new Charge(3, 10, 3000),
                    new Wander(.5))
                    )
                    )
        ;
    }
}
