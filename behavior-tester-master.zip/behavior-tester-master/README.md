creepylava state machine behavior tester
=============================

This project exists to help people get started with making behaviors in creepylava's state machine behavior system. It is basically an identical copy of this repo: https://github.com/rirze/rotmg_svr . Some unneeded projects have been removed and some minor edits/inclusions have been made to make it more testing friendly.

Getting started:
----------------

1) Download and start redis for your os. A version of redis for Windows has been included with this repo (redis-server.exe).

2) Build the project with a C# ide/compiler of your choosing. This will create two files, server.exe and wServer.exe (among 
others) located in the ./bin/Debug/ directory of your project folder.

3) Run the server.exe with administrative privileges.

4) Run the wServer.exe.

5) Open the included rotmg.swf.

6) Test away.
